catalog = [
    {
        "_id": "a",
        "title": "Black Hoodie",
        "price": 55.00,
        "stock": 20,
        "category": "clothing",
        "image": "blackhoodie.jpeg"
    },

    { 
        "_id": "b",
        "title": "Green Hoodie",
        "price": 50.00,
        "stock": 20,
        "category": "clothing",
        "image": "greenhoodie.jpeg"
    },

    { 
        "_id": "c",
        "title": "Pink Hoodie",
        "price": 55.00,
        "stock": 20,
        "category": "clothing",
        "image": "pinkhoodie.jpeg"
    },

    { 
        "_id": "d",
        "title": "Purple Hoodie",
        "price": 50.00,
        "stock": 20,
        "category": "clothing",
        "image": "purplehoodie.jpeg"   
    },

    { 
        "_id": "e",
        "title": "White Hoodie",
        "price": 50.00,
        "stock": 20,
        "category": "clothing",
        "image": "whitehoodie.jpeg"
    },
]


