
# I;m a comment, not code


# variables
name = "Santiago"
last = "Quijano"
age = 22
found = False
price = 100.00


print(name + " " + last)

print(age + 1)
print(age * 1)
print("Hi I'm {name}, and my age is " + str(age))

print(f"Hi I'm {name}, and my age is: {age}")



if age < 100:
    print("Don't worry playa")
    print("ok OG")
    print("Now go buy me some smokes")

elif age == 100:
    print("Congrats you got to a century!!!!")

else:
    print("Sorry, you are getting old!!!")


print("I'm not :(")




def say_hello():
    print("Hello from a fn")
    print("I'm inside the fn")


say_hello()
say_hello()
say_hello()




